import os, platform
import time

from transformers import AutoTokenizer, AutoModel
from model import LLMModel
import jittor as jt
import torch

from model import MODEL_PATHS

os_name = platform.system()
clear_command = 'cls' if os_name == 'Windows' else 'clear'
stop_stream = False

def build_prompt(history):
    prompt = ''

    for query, response in history:

        prompt += f"\n用户输入：{query}"
        prompt += f"\nChatGLM-6B：{response}"

    return prompt

class ChatGLMMdoel(LLMModel):
    def __init__(self, args) -> None:
        super().__init__()
        self.tokenizer = AutoTokenizer.from_pretrained(os.path.dirname(__file__), cache_dir = MODEL_PATHS, trust_remote_code=True)
        self.model = AutoModel.from_pretrained(os.path.dirname(__file__), cache_dir = MODEL_PATHS, trust_remote_code=True)
        if jt.has_cuda:
            self.model.half().cuda()
        else:
            self.model.float32()
            torch.half = torch.float
            torch.Tensor.half = torch.Tensor.float
        self.model.eval()

    def chat(self) -> str:
        global stop_stream
        history = []

        while True:

            start = time.time()
            text = input("用户输入:")
            responses = ""
            i = 0
            for response, history in self.model.stream_chat(self.tokenizer, text, history=history):

                if i==0:
                    print("GLM推理用时：",time.time()-start)
                    i+=1
                response = response.replace(responses,"")
                responses += response

            print(responses)

            print(flush=True)
    
    def run_web_demo(self, input_text, history=[]):
        while True:
            yield self.run(input_text, history=history)

    def run(self, text, history=[]):
        return self.model.chat(self.tokenizer, text, history=history)

def get_model(args):
    return ChatGLMMdoel(args)