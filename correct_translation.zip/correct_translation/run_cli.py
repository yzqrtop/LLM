'''
@PRODUCT ：PyCharm
@Project ：correct_translation 
@File    ：run_cli.py
@IDE     ：PyCharm 
@Author  ：YZQ
@Date    ：2023/7/31 10:33 
'''

import jittor
jittor.flags.use_cuda = 1
jittor.flags.lazy_execution = 0


import argparse
import model

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=model.availabel_models,default="chatglm")
    args = parser.parse_args()
    model = model.get_model(args)
    model.chat()
