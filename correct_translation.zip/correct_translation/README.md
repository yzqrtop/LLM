# 环境配置
```bash

# 创建虚拟环境，环境名可自定义
conda create -n LLM_translation_py39 python=3.9

# 激活环境,根据自己定义的环境名进入虚拟环境
conda activate LLM_translation_py39

# 进入项目所在文件
cd /home/nmnormal1/work/yzq/LLMModel/correct_translation/

# 安装环境
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

```

# 运行
```angular2html 这个是拓展了翻译指令提示的版本，推理需要GPU显存15G左右；若GPU不够，可以看我下面写的错误提示。
# 设置cuda显示6，7号卡，单个节点跑模型推理
CUDA_VISIBLE_DEVICES="6,7" mpirun -np 1 python run_cli.py chatglm
```

# 结果说明

- 针对翻译场景做了指令微调，每次输入错误英文句子时需要加上“上一句改正”，这样效果比较好，比如：

```bash
I hav a gud ideea. 上一句改正。
```

结果如下：
![img.png](img.png)
# 出现错误解决
- GPU不足
```bash
export JT_SAVE_MEM=1

# 限制device内存（如gpu、tpu等）最多使用8G
export device_mem_limit=8000000000
```
- 提示输入utf-8异常，这是输入中文出现的错误，可以在记事本里写完，复制到剪贴板输出。
